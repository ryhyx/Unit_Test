﻿namespace MobileReview
{
    public class MidRangeMobilePhone : MobilePhone
    {
        public override double MobilePhonePrice => 200;
        public override double WarrantyFeeBasedOnPercent => 6;
    }
}