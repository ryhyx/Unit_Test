﻿namespace MobileReview
{
    public class FlagshipMobilePhone : MobilePhone
    {
        public override double MobilePhonePrice => 500;
        public override double WarrantyFeeBasedOnPercent => 10;
    }
}
