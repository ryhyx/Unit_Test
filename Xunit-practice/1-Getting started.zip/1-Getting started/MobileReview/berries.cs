﻿//Quiz
namespace MobileReview
{
    public class Fruits
    {
        public List<string> Berries = new List<string>()
        {
        "Strawberry",
        "Blueberry",
        "Raspberry",
        "Cranberry"
        };
    };
    
}
